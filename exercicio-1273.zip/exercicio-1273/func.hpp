#include<iostream>

#ifndef _FUNC_
#define _FUNC_

//  Preencer o vetor
    void preencher_vetor(std::string vetor[], int tamanho_vet);

//  Printar o vetor
    void print_vetor(std::string vetor[], int tamanho_vet);

//  Garda tamanho da maior string
    void maior_string(std::string vetor[], int tamanho_vet, int *tamanho);

//  Altera string do vetor
    void altera_string(std::string vetor[], int tamanho_vet, int tamenho);

#endif //_FUNC_